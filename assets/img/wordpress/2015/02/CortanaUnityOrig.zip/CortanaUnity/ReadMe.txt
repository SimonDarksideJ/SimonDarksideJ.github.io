This is the Cortana demo app which highlights the use of Cortana's amazing speech capabilities on Windows Phone

**To use this demo**
In order to deploy this demo you need to:

    * Open the project in Unity
    * Build the Project for Windows Phone 8.1 (Windows Store target with Phone 8.1 SDK)
    * Open the Windows Phone project in Visual Studio
    * Build and deploy to a device to test.

Note, The demo will not function properly on the emulator as it does not have Microphone support.