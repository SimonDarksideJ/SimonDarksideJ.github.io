This is the Cortana demo app which highlights the use of Cortana's amazing speech capabilities on Windows 10

**To use this demo**
In order to deploy this demo you need to:

    * Open the project in Unity
    * Build the Project for Windows 10 UWP to the Export\WindowsUniversal folder
	(Windows Store target with the Universal 10 / XAML SDK)
    * Open the Windows Universal project in Visual Studio
    * Build and deploy to a device to test.

Note, The demo will not function properly on the emulator as it does not have Microphone support.

**Note 2
Ensure you have the INTERNET capability enabled when you package for APPX sideloading or Store deployment.
Visual Studio and the test kit will NOT warn you if you have not enabled it.  Cortana will NOT work without this capability