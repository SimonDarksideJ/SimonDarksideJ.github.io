﻿using UnityEngine;
using System.Collections;

public class PlayerFeedback : MonoBehaviour {

	private UnityEngine.UI.Button button;
	public string[] CharacterText;
	// Use this for initialization
	void Start () {
		button = GetComponent<UnityEngine.UI.Button>();
		button.onClick.AddListener(() => SelectRandomTextAndSpeak());
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	private void SelectRandomTextAndSpeak()
	{
		if (CharacterText.Length > 0)
		{
			var textToSpeak = CharacterText[Random.Range(0, CharacterText.Length - 1)];
			CortanaInterop.YellAtPlayer(textToSpeak);
		}
	}
}
