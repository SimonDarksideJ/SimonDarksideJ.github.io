﻿using UnityEngine;
using System.Collections;

public class UpdateTextFromCortana : MonoBehaviour {

	private UnityEngine.UI.Text displayText;

	// Use this for initialization
	void Start () {
	 displayText = GetComponent<UnityEngine.UI.Text>();
	}
	
	// Update is called once per frame
	void Update () {
		if (!string.IsNullOrEmpty(CortanaInterop.CortanaText))
		{
			displayText.text = CortanaInterop.CortanaText;
		}
	}
}
