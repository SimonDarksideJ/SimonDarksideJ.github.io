﻿using UnityEngine;

public class AreYouListening : MonoBehaviour {

    public GameObject statusObject;

    // Update is called once per frame
    void Update () {
        if (!statusObject.activeSelf && CortanaInterop.SpeechInProgress)
        {
            statusObject.SetActive(true);
        }
        else if (statusObject.activeSelf && !CortanaInterop.SpeechInProgress)
        {
            statusObject.SetActive(false);
        }
    
    }
}
