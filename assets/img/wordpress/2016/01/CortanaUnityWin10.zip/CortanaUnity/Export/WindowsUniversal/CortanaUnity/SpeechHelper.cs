﻿using System;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.UI.Xaml.Controls;

namespace CortanaUnity
{
    public class SpeechHelper
    {
        private static Windows.Media.SpeechRecognition.SpeechRecognizer speechRecognizer;
        private static IAsyncOperation<Windows.Media.SpeechRecognition.SpeechRecognitionResult> recognitionOperation;
        private static Windows.Media.SpeechSynthesis.SpeechSynthesizer synth;
        private static MediaElement mediaElement;

        private static Windows.UI.Core.CoreDispatcher dispatcher;


        public static void HandleSpeechCommand(IActivatedEventArgs args)
        {
            var commandArgs = args as Windows.ApplicationModel.Activation.VoiceCommandActivatedEventArgs;
            Windows.Media.SpeechRecognition.SpeechRecognitionResult speechRecognitionResult = commandArgs.Result;

            // If so, get the name of the voice command, the actual text spoken, and the value of Command.
            string voiceCommandName = speechRecognitionResult.RulePath[0];
            string textSpoken = speechRecognitionResult.Text;

            CortanaInterop.CortanaText = textSpoken;
            switch (voiceCommandName)
            {
                case "playerSearch":
                    CortanaInterop.CortanaText = "Searching for Player {" + textSpoken + "}...";
                    foreach (var item in speechRecognitionResult.RulePath)
                    {
                        CortanaInterop.CortanaText += "[" + item + "],";
                    }
                    break;

                // Cases for other voice commands.

                default:
                    // There is no match for the voice command name.
                    break;
            }
        }
        public static async System.Threading.Tasks.Task InitialiseSpeechRecognition()
        {
            // Create an instance of SpeechRecognizer.
            speechRecognizer = new Windows.Media.SpeechRecognition.SpeechRecognizer();

            // Add a web search grammar to the recognizer.
            var dictationGrammar = new Windows.Media.SpeechRecognition.SpeechRecognitionTopicConstraint(Windows.Media.SpeechRecognition.SpeechRecognitionScenario.Dictation, "dication");

            speechRecognizer.Constraints.Add(dictationGrammar);

            // Compile the dictation grammar by default.
            await speechRecognizer.CompileConstraintsAsync();
        }

        public static async void StartRecognizing(object sender, EventArgs e)
        {
            CortanaInterop.SpeechInProgress = true;

            // Start recognition.
            recognitionOperation = speechRecognizer.RecognizeAsync();
            Windows.Media.SpeechRecognition.SpeechRecognitionResult speechRecognitionResult = await recognitionOperation;

            if (speechRecognitionResult.Status == Windows.Media.SpeechRecognition.SpeechRecognitionResultStatus.Success)
            {
                // Do something with the recognition result.
                CortanaInterop.CortanaText = speechRecognitionResult.Text;
            }
            else
            {
                CortanaInterop.CortanaText = "Sorry, could not hear you";

            }
            CortanaInterop.SpeechInProgress = false;
        }

        public static void InitialiseSpeechSynthesis(MediaElement MediaElement)
        {
            // The media object for controlling and playing audio.
            mediaElement = MediaElement;

            // The object for controlling the speech synthesis engine (voice).
            synth = new Windows.Media.SpeechSynthesis.SpeechSynthesizer();

            // Save the UI thread dispatcher to allow speech status messages to be shown on the UI.
            dispatcher = Windows.UI.Core.CoreWindow.GetForCurrentThread().Dispatcher;
        }

        public static async void StartSpeaking(object sender, EventArgs e)
        {
            var textToSpeech = (string)sender;
            if (mediaElement != null)
            {
                await dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                {
                    if (mediaElement.CurrentState.Equals(Windows.UI.Xaml.Media.MediaElementState.Playing))
                    {
                        mediaElement.Stop();
                    }
                });
                if (!CortanaInterop.SpeechInProgress && !string.IsNullOrEmpty(textToSpeech))
                {
                    try
                    {
                        // Generate the audio stream from plain text.
                        Windows.Media.SpeechSynthesis.SpeechSynthesisStream stream = await synth.SynthesizeTextToStreamAsync(textToSpeech);
                        await dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                        {
                            mediaElement.AutoPlay = true;
                            mediaElement.SetSource(stream, stream.ContentType);
                            mediaElement.Play();
                        });

                    }
                    catch (System.IO.FileNotFoundException)
                    {
                        // If media player components are unavailable, (eg, using a N SKU of windows), we won't
                        // be able to start media playback. Handle this gracefully
                        var messageDialog = new Windows.UI.Popups.MessageDialog("Media player components unavailable");
                        await messageDialog.ShowAsync();
                    }
                    catch (Exception)
                    {
                        // If the text is unable to be synthesized, throw an error message to the user.
                        mediaElement.AutoPlay = false;
                        var messageDialog = new Windows.UI.Popups.MessageDialog("Unable to synthesize text");
                        await messageDialog.ShowAsync();
                    }
                }
            }

        }
    }
}
