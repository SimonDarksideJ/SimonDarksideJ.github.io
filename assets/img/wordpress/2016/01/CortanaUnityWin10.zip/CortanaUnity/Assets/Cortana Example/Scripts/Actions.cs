﻿using UnityEngine;
using System.Collections;

public class Actions : MonoBehaviour {

	public void StartSpeechRecognition()
	{
		CortanaInterop.GetMeSomeVoice();
	}

	public void SendAToast()
	{
		CortanaInterop.YouToastThatPlayer();
	}
}
