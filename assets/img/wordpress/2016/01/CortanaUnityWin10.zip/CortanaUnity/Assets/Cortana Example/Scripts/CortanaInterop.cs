﻿using System;
using UnityEngine;

public class CortanaInterop : MonoBehaviour {

    public static string CortanaText;

    public static bool SpeechInProgress;

    public static event EventHandler SpeechRequested;
    public static void GetMeSomeVoice()
    {
        if (SpeechRequested != null && !SpeechInProgress)
        {
            SpeechRequested(null, null);
        }
    }

    public static event EventHandler SpeechSynthRequested;
    public static void YellAtPlayer(string textToSpeak)
    {
        if (SpeechSynthRequested != null && !SpeechInProgress)
        {
            SpeechSynthRequested(textToSpeak, null);
        }
    }

    public static event EventHandler ToastRequested;
    public static void YouToastThatPlayer()
    {
        if (ToastRequested != null)
        {
            ToastRequested(null, null);
        }
    }

}
